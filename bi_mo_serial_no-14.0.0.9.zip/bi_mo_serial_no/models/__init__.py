# -*- coding: utf-8 -*-
from . import inherited_res_config_setting
from . import inherited_res_company
from . import mrp_production
from . import mrp_abstract_workorder